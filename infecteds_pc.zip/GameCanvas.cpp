#include "GameCanvas.h"

const int GameCanvas::ENEMYANIMATION_WALK = 0;
const int GameCanvas::ENEMYANIMATION_ATTACK = 1;
const int GameCanvas::ENEMYANIMATION_DEATH = 2;

const int GameCanvas::BULLETSENDER_CHARACTER = 0;
const int GameCanvas::BULLETSENDER_ENEMY = 1;


GameCanvas::GameCanvas(gApp* root) : gBaseCanvas(root) {
	this->root = root;
	this->level = 0;
	this->score = 0;
}

GameCanvas::~GameCanvas() {
}

void GameCanvas::setup() {
	loadcounter = 0;
	loadcounterlimit = 100;
	gamestate = GAMESTATE_LOADING;
	loadInitialAssets();
}

void GameCanvas::update() {
//	gLogi("GameCanvas") << "update";
	if(gamestate == GAMESTATE_LOADING) {
		loadAssets();
		return;
	}
	if(pausedialogshown) return;
	moveBullets();
	if(gameoverdialogshown) return;
	moveCharacter();
	moveCamera();
	moveEnemies();
	moveObjects();
}

void GameCanvas::draw() {
	//gLogi("GameCanvas") << "draw";
	if(gamestate == GAMESTATE_LOADING) {
		drawLoadingScreen();
		return;
	}
	drawBackground();
	drawObjects();
	drawEnemies();
	drawCharacter();
	drawBullets();
	drawLevelMap();
	drawGUI();
	//fpsfont.drawText("FPS: " + gToStr(root->getFramerate()), 10, 22);
}

void GameCanvas::moveObjects() {
	if(ishealthboxtaken) return;
	if(std::fabs(healthboxy - healthboxinitialy) >= healthboxdylimit) {
		healthboxdy = -healthboxdy;
	}
	healthboxy += healthboxdy;
}

void GameCanvas::moveCharacter() {
	if((keystate & KEY_W) != 0) {
		cdx = std::sin(gDegToRad(crot)) * cspeed;
		cdy = -std::cos(gDegToRad(crot)) * cspeed;
	} else if((keystate & KEY_S) != 0) {
		cdx = -std::sin(gDegToRad(crot)) * cspeed;
		cdy = std::cos(gDegToRad(crot)) * cspeed;
	}

	if((keystate & KEY_D) != 0) {
		cdx += std::cos(gDegToRad(crot)) * cspeed;
		cdy += std::sin(gDegToRad(crot)) * cspeed;
	} else if((keystate & KEY_A) != 0) {
		cdx += -std::cos(gDegToRad(crot)) * cspeed;
		cdy += -std::sin(gDegToRad(crot)) * cspeed;
	}

	cx += cdx;
	cy += cdy;

	if(cdx != 0.0f || cdy != 0.0f) {
		characterframecounter++;
		if(characterframecounter >= characterframecounterlimit) {
			characterframeno++;
			if(characterframeno >= characterframenum) characterframeno = 0;
			characterframecounter = 0;
		}
	}

	if(!ishealthboxtaken && checkCollision(healthboxx, healthboxy, healthboxx + hbw, healthboxy + hbh, cx + camx, cy + camy, cx + camx + cgw, cy + camy + cgh)) {
		chealth += 20;
		if(chealth > cinitialhealth) chealth = cinitialhealth;
		ishealthboxtaken = true;
	}
}

void GameCanvas::moveCamera() {
	camleftmargin = mcagw4;
	if(camx <= 0) camleftmargin = 0;
	camrightmargin = mcagw34;
	if(camx >= bgw - gw) camrightmargin = gw;
    camtopmargin = mcagh4;
    if(camy <= 0) camtopmargin = 0;
	cambottommargin = mcagh34;
	if(camy >= bgh - gh) cambottommargin = gh;

	if(cx + cgw >= camrightmargin || cx < camleftmargin) {
		cx -= cdx;
		camx += cdx;
		if(camx < 0) camx = 0;
		if(camx > bgw - gw) camx = bgw - gw;
	}
	if(cy + cgh >= cambottommargin || cy < camtopmargin) {
		cy -= cdy;
		camy += cdy;
		if(camy < 0) camy = 0;
		if(camy > bgh - gh) camy = bgh - gh;
	}

	cdx = 0.0f;
	cdy = 0.0f;
}

void GameCanvas::moveEnemies() {
	for(meni = 0; meni < enemynum; meni++) {
		if(enemies[meni].getAnimationNo() != ENEMYANIMATION_DEATH)	enemies[meni].setRotation(gRadToDeg(std::atan2(cy + camy + (cgh2) - (enemies[meni].getY() + (engh2)), cx + camx + (cgw2) - (enemies[meni].getX() + (engw2)))) - 90.0f);
		float edx = 0.0f;
		float edy = 0.0f;
		if(enemies[meni].getAnimationNo() != ENEMYANIMATION_DEATH && enemies[meni].getX() + engw > camx && enemies[meni].getX() < camx + gw && enemies[meni].getY() + engh > camy && enemies[meni].getY() < camy + gh) {
			edx = -std::sin(gDegToRad(enemies[meni].getRotation()));
			edy = std::cos(gDegToRad(enemies[meni].getRotation()));
		}

		enemies[meni].setPosition(enemies[meni].getX() + edx, enemies[meni].getY() + edy);

		if(edx != 0 || edy != 0) {
			bool iscollided = checkCollision(enemies[meni].getX() + 55, enemies[meni].getY() + 28, enemies[meni].getX() + engw - 57, enemies[meni].getY() + engh - 68, cx + camx, cy + camy + 50, cx + camx + cgw, cy + camy + cgh);
			if(iscollided) {
				if(root->isSoundPlaying(gApp::SOUNDEFFECT_ENEMYFOOTSTEP)) root->setSoundPause(true, gApp::SOUNDEFFECT_ENEMYFOOTSTEP);
				if(enemies[meni].getAnimationNo() == ENEMYANIMATION_WALK) enemies[meni].setFrameNo(0);
				enemies[meni].setAnimationNo(ENEMYANIMATION_ATTACK);
				enemies[meni].setPosition(enemies[meni].getX() - edx, enemies[meni].getY() - edy);
				edx = 0.0f;
				edy = 0.0f;
				chealth -= 0.15f;
				score -= 5;
				if(score < 0) score = 0;
				if(chealth <= 0) {
					chealth = 0;
					scorex = dialogx + (pdgw - scorefont.getStringWidth(gToStr(score))) / 2;
					gameoverdialogshown = true;
				}
			} else {
				root->setSoundPause(false, gApp::SOUNDEFFECT_ENEMYFOOTSTEP);
				if(!root->isSoundPlaying(gApp::SOUNDEFFECT_ENEMYFOOTSTEP)) root->playSound(gApp::SOUNDEFFECT_ENEMYFOOTSTEP);
				if(enemies[meni].getAnimationNo() == ENEMYANIMATION_ATTACK) enemies[meni].setFrameNo(0);
				enemies[meni].setAnimationNo(ENEMYANIMATION_WALK);
			}
		}
		enemies[meni].setFrameCounter(enemies[meni].getFrameCounter() + 1);
		if(enemies[meni].getFrameCounter() >= enemies[meni].getFrameCounterLimit()) {
			enemies[meni].setFrameNo(enemies[meni].getFrameNo() + 1);
			if(enemies[meni].getFrameNo() >= enemyframenum[enemies[meni].getAnimationNo()]) {
				if(enemies[meni].getAnimationNo() == ENEMYANIMATION_DEATH) enemies[meni].setFrameNo(enemyframenum[ENEMYANIMATION_DEATH] - 1);
				else enemies[meni].setFrameNo(0);
			}
			enemies[meni].setFrameCounter(0);
		}
		if(enemies[meni].getAnimationNo() == ENEMYANIMATION_WALK && (edx != 0 || edy != 0) && enemies[meni].getFrameCounter() == 0) {
			if(enemies[meni].getFrameNo() == 3) {
				float bulletx = (enemies[meni].getX() + (engw2)) - (std::sin(gDegToRad(enemies[meni].getRotation() + enemyrighthandangle)) * enemyrighthanddistance);
				float bullety = (enemies[meni].getY() + (engh2)) + (std::cos(gDegToRad(enemies[meni].getRotation() + enemyrighthandangle)) * enemyrighthanddistance);
				float bulletdx = -std::sin(gDegToRad(enemies[meni].getRotation())) * bulletspeed;
				float bulletdy = std::cos(gDegToRad(enemies[meni].getRotation())) * bulletspeed;
				generateBullet(bulletx, bullety, bulletdx, bulletdy, enemies[meni].getRotation(), BULLETSENDER_ENEMY);
			} else if(enemies[meni].getFrameNo() == 7) {
				float bulletx = (enemies[meni].getX() + (engw2)) - (std::sin(gDegToRad(enemies[meni].getRotation() + enemylefthandangle)) * enemylefthanddistance);
				float bullety = (enemies[meni].getY() + (engh2)) + (std::cos(gDegToRad(enemies[meni].getRotation() + enemylefthandangle)) * enemylefthanddistance);
				float bulletdx = -std::sin(gDegToRad(enemies[meni].getRotation())) * bulletspeed;
				float bulletdy = std::cos(gDegToRad(enemies[meni].getRotation())) * bulletspeed;
				generateBullet(bulletx, bullety, bulletdx, bulletdy, enemies[meni].getRotation(), BULLETSENDER_ENEMY);
			}
		}
	}
}

void GameCanvas::moveBullets() {
	for(mbui = bullets.size() - 1; mbui >= 0; mbui--) {
		bullets[mbui][0] += bullets[mbui][2];
		bullets[mbui][1] += bullets[mbui][3];
		bullets[mbui][5]++;
		if(bullets[mbui][5] >= 30) {
			bullets.erase(bullets.begin() + mbui);
			continue;
		}
		if(bullets[mbui][0] + bugw0 < camx || bullets[mbui][1] + bugh0 < camy || bullets[mbui][0] >= camx + gw || bullets[mbui][1] >= camy + gh) {
			bullets.erase(bullets.begin() + mbui);
			continue;
		}
		if(bullets[mbui][6] == BULLETSENDER_CHARACTER) {
			for(mbuj = 0; mbuj < enemynum; mbuj++) {
				bool iscollided = false;
				if(enemies[mbuj].getAnimationNo() != ENEMYANIMATION_DEATH) {
					iscollided = checkCollision(bullets[mbui][0], bullets[mbui][1], bullets[mbui][0] + bugw0, bullets[mbui][1] + bugh0, enemies[mbuj].getX(), enemies[mbuj].getY(), enemies[mbuj].getX() + engw, enemies[mbuj].getY() + engh);
					if(iscollided) {
						root->playSound(gApp::SOUNDEFFECT_ENEMYDEATH);
						enemies[mbuj].setAnimationNo(ENEMYANIMATION_DEATH);
						enemies[mbuj].setFrameNo(0);
						deadenemynum++;
						score += 50;
						if(deadenemynum >= enemynum) {
							scorex = dialogx + (pdgw - scorefont.getStringWidth(gToStr(score))) / 2;
							youwindialogshown = true;
						}
						bullets.erase(bullets.begin() + mbui);
						break;
					}
				}
			}
		} else {
			bool iscollided = false;
			iscollided = checkCollision(bullets[mbui][0], bullets[mbui][1], bullets[mbui][0] + bugw1, bullets[mbui][1] + bugh1, camx + cx, camy + cy, camx + cx + cgw, camy + cy + cgh);
			if(iscollided) {
				chealth--;
				if(!youwindialogshown) {
					score -= 5;
					if(score < 0) score = 0;
				}

				if(chealth <= 0) {
					chealth = 0;
					scorex = dialogx + (pdgw - scorefont.getStringWidth(gToStr(score))) / 2;
					gameoverdialogshown = true;
				}
				bullets.erase(bullets.begin() + mbui);
				continue;
			}
		}
	}
}

void GameCanvas::drawObjects() {
	if(!ishealthboxtaken) healthbox.draw(healthboxx - camx, healthboxy - camy);
}

void GameCanvas::drawBackground() {
	background.drawSub(0, 0, gw, gh, camx, camy, gw, gh);
}

void GameCanvas::drawCharacter() {
    character[characterframeno].draw(cx, cy, cgw, cgh, crot);
}

void GameCanvas::drawEnemies() {
	for(deni = 0; deni < enemynum; deni++) {
		enemy[enemies[deni].getAnimationNo()][enemies[deni].getFrameNo()].draw(enemies[deni].getX() - camx, enemies[deni].getY() - camy, engw, engh, enemies[deni].getRotation());
	}
}

void GameCanvas::drawLevelMap() {
	levelmap.draw(levelmapx, levelmapy);
	for(dlmi = 0; dlmi < enemynum; dlmi++) {
		if(enemies[dlmi].getAnimationNo() != ENEMYANIMATION_DEATH) levelmapsign2.draw(levelmapx + 2 + enemies[dlmi].getX() / 32, levelmapy + 2 + enemies[dlmi].getY() / 32);
	}
	levelmapsign1.draw(levelmapx + 2 + ((cx + camx) / 32), levelmapy + 2 + ((cy + camy) / 32));
	if(!ishealthboxtaken) levelmapsign3.draw(levelmapx + 2 + (healthboxx / 32), levelmapy + 2 + (healthboxy / 32));
}

void GameCanvas::drawBullets() {
	for(dbui = 0; dbui < bullets.size(); dbui++) {
		bulletimage[(int)bullets[dbui][6]].draw(bullets[dbui][0] - camx, bullets[dbui][1] - camy, bulletimage[0].getWidth(), bulletimage[0].getHeight(), bullets[dbui][4]);
	}
}

void GameCanvas::drawGUI() {
	charactericon.draw(charactericonx, charactericony);
	healthicon.draw(healthiconx, healthicony);
	shieldicon.draw(shieldiconx, shieldicony);
	progressbarbackground.draw(healthbarbackgroundx, healthbarbackgroundy);
	healthbar.drawSub(healthbarbackgroundx, healthbarbackgroundy, dguihbgw * chealth / cinitialhealth, dguihbgh, 0, 0, dguihbgw * chealth / cinitialhealth, dguihbgh);
	progressbarframe.draw(healthbarframex, healthbarframey);
	progressbarbackground.draw(shieldbarbackgroundx, shieldbarbackgroundy);
	shieldbar.drawSub(shieldbarbackgroundx, shieldbarbackgroundy, dguisbgw * (enemynum - deadenemynum) / enemynum, dguisbgh, 0, 0, dguisbgw * (enemynum - deadenemynum) / enemynum, dguisbgh);
	progressbarframe.draw(shieldbarframex, shieldbarframey);
	if(pausedialogshown) {
		pausedialog.draw(dialogx, dialogy);
		continuebutton.draw(leftbuttonx, leftbuttony);
		mainmenubutton.draw(rightbuttonx, rightbuttony);
		setColor(0, 0, 0);
		scoretextfont.drawText("SCORE", scoretextx + 4, scoretexty + 4);
		scorefont.drawText(gToStr(score), scorex + 4, scorey + 4);
		setColor(185, 204, 104);
		scorefont.drawText(gToStr(score), scorex, scorey);
		scoretextfont.drawText("SCORE", scoretextx, scoretexty);
		setColor(255, 255, 255);
	}
	if(gameoverdialogshown) {
		gameoverdialog.draw(dialogx, dialogy);
		replaybutton.draw(leftbuttonx, leftbuttony);
		mainmenubutton.draw(rightbuttonx, rightbuttony);
		setColor(0, 0, 0);
		scoretextfont.drawText("SCORE", scoretextx + 4, scoretexty + 4);
		scorefont.drawText(gToStr(score), scorex + 4, scorey + 4);
		setColor(185, 204, 104);
		scorefont.drawText(gToStr(score), scorex, scorey);
		scoretextfont.drawText("SCORE", scoretextx, scoretexty);
		setColor(255, 255, 255);
	}
	if(youwindialogshown) {
		youwindialog.draw(dialogx, dialogy);
		nextlevelbutton.draw(leftbuttonx, leftbuttony);
		mainmenubutton.draw(rightbuttonx, rightbuttony);
		setColor(0, 0, 0);
		scoretextfont.drawText("SCORE", scoretextx + 4, scoretexty + 4);
		scorefont.drawText(gToStr(score), scorex + 4, scorey + 4);
		setColor(185, 204, 104);
		scorefont.drawText(gToStr(score), scorex, scorey);
		scoretextfont.drawText("SCORE", scoretextx, scoretexty);
		setColor(255, 255, 255);
	}
}

void GameCanvas::keyPressed(int key) { // W=87 ,S=83 ,A=65 ,D=68, ESC=256
	//gLogi("GameCanvas") << "keyPressed:" << key;
	if(!(gameoverdialogshown || youwindialogshown) && key == 256) {
		pausedialogshown = !pausedialogshown;
		scorex = dialogx + (pdgw - scorefont.getStringWidth(gToStr(score))) / 2;
		return;
	}

	int keypressed = KEY_NONE;
	switch(key) {
	case 87:
		keypressed = KEY_W;
		break;
	case 83:
		keypressed = KEY_S;
		break;
	case 65:
		keypressed = KEY_A;
		break;
	case 68:
		keypressed = KEY_D;
		break;
	default:
		break;
	}
	keystate |= keypressed;
}

void GameCanvas::keyReleased(int key) {
//	gLogi("GameCanvas") << "keyReleased:" << key;
	int keypressed = KEY_NONE;
	switch(key) {
		case 87:
			keypressed = KEY_W;
			break;
		case 83:
			keypressed = KEY_S;
			break;
		case 65:
			keypressed = KEY_A;
			break;
		case 68:
			keypressed = KEY_D;
			break;
		default:
			break;
		}
	keystate &= ~keypressed;
}

void GameCanvas::mouseMoved(int x, int y) {
//	gLogi("GameCanvas") << "mouseMoved" << ", x:" << x << ", y:" << y;
	if(pausedialogshown || gameoverdialogshown) return;
	crot = gRadToDeg(std::atan2(y - (cy + (cgh2)), x - (cx + (cgw2)))) + 90.0f;
}

void GameCanvas::mouseDragged(int x, int y, int button) {
//	gLogi("GameCanvas") << "mouseDragged" << ", x:" << x << ", y:" << y << ", b:" << button;
}

void GameCanvas::mousePressed(int x, int y, int button) {
}

void GameCanvas::mouseReleased(int x, int y, int button) {
//	gLogi("GameCanvas") << "mouseReleased" << ", button:" << button;
	if(gameoverdialogshown) {
		if(x >= leftbuttonx && x <= leftbuttonx + replaybutton.getWidth() && y >= leftbuttony && y <= leftbuttony + replaybutton.getHeight()) {
			root->playSound(gApp::SOUNDEFFECT_NEXT);
			GameCanvas* newcanvas = new GameCanvas(root);
			root->setCurrentCanvas(newcanvas);
		}
		if(x >= rightbuttonx && x <= rightbuttonx + mainmenubutton.getWidth() && y >= rightbuttony && y <= rightbuttony + mainmenubutton.getHeight()) {
			root->setMusicPause(true, gApp::MUSIC_GAME);
			MenuCanvas* newcanvas = new MenuCanvas(root);
			root->setCurrentCanvas(newcanvas);
		}
		return;
	}
	if(pausedialogshown) {
		if(x >= leftbuttonx && x <= leftbuttonx + continuebutton.getWidth() && y >= leftbuttony && y <= leftbuttony + continuebutton.getHeight()) {
			pausedialogshown = false;
		}
		if(x >= rightbuttonx && x <= rightbuttonx + mainmenubutton.getWidth() && y >= rightbuttony && y <= rightbuttony + mainmenubutton.getHeight()) {
			root->setMusicPause(true, gApp::MUSIC_GAME);
			MenuCanvas* newcanvas = new MenuCanvas(root);
			root->setCurrentCanvas(newcanvas);
		}
		return;
	}
	if(youwindialogshown) {
		if(x >= leftbuttonx && x <= leftbuttonx + continuebutton.getWidth() && y >= leftbuttony && y <= leftbuttony + continuebutton.getHeight()) {
			root->playSound(gApp::SOUNDEFFECT_NEXT);
			GameCanvas* newcanvas = new GameCanvas(root);
			newcanvas->setLevelNo(level + 1);
			newcanvas->setScore(score);
			root->setCurrentCanvas(newcanvas);
		}
		if(x >= rightbuttonx && x <= rightbuttonx + mainmenubutton.getWidth() && y >= rightbuttony && y <= rightbuttony + mainmenubutton.getHeight()) {
			root->setMusicPause(true, gApp::MUSIC_GAME);
			MenuCanvas* newcanvas = new MenuCanvas(root);
			root->setCurrentCanvas(newcanvas);
		}
		return;
	}
	float bulletx = (cx + camx + (cgw2)) + (std::sin(gDegToRad(crot + muzzleangle)) * muzzledistance);
	float bullety = (cy + camy + (cgh2)) - (std::cos(gDegToRad(crot + muzzleangle)) * muzzledistance);
	float bulletdx = std::sin(gDegToRad(crot)) * bulletspeed;
	float bulletdy = -std::cos(gDegToRad(crot)) * bulletspeed;
	generateBullet(bulletx, bullety, bulletdx, bulletdy, crot, BULLETSENDER_CHARACTER);
	root->playSound(gApp::SOUNDEFFECT_GUNSHOT);
}

void GameCanvas::mouseEntered() {
}

void GameCanvas::mouseExited() {
}

void GameCanvas::showNotify() {

}

void GameCanvas::hideNotify() {

}

bool GameCanvas::checkCollision(int xLeft1, int yUp1, int xRight1, int yBottom1, int xLeft2, int yUp2, int xRight2, int yBottom2) {
	if(xLeft1 < xRight2 && xRight1 > xLeft2 && yBottom1 > yUp2 && yUp1 < yBottom2) {
		return true;
	}
	return false;
}

void GameCanvas::generateBullet(float bulletx, float bullety, float bulletdx, float bulletdy, float rotation, int bulletSender) {
	std::vector<float> newbullet;
	newbullet.push_back(bulletx);
	newbullet.push_back(bullety);
	newbullet.push_back(bulletdx);
	newbullet.push_back(bulletdy);
	newbullet.push_back(rotation);
	newbullet.push_back(0);
	newbullet.push_back(bulletSender);

	bullets.push_back(newbullet);
}

void GameCanvas::setLevelNo(int levelNo) {
	level = levelNo;
}

void GameCanvas::setCharacterNo(int characterNo) {
	this->characterno = characterNo;
}

void GameCanvas::setScore(int score) {
	this->score = score;
}

void GameCanvas::loadInitialAssets() {
	loadingbackground.loadImage("menu/arkaplan.jpg");
	loadingtext.loadImage("oyun/gui/gui_loadingtext2.png");
	loadingbar.loadImage("oyun/gui/gui_progressbar.png");
	loadingbarx = (getWidth() - loadingbar.getWidth()) / 2;
	loadingbary = (getHeight() - loadingbar.getHeight()) / 2;
	loadingtextx = loadingbarx;
	loadingtexty = loadingbary - loadingtext.getHeight() * 2;
}

void GameCanvas::loadAssets() {
	loadAsset(loadcounter);
	loadcounter++;
	if(loadcounter >= loadcounterlimit) gamestate = GAMESTATE_PLAYING;
}

void GameCanvas::loadAsset(int assetNo) {
	switch(assetNo) {
	case 0:
		background.loadImage("oyun/haritalar/arkaplan" + gToStr((level % 3) + 1) + ".jpg");
		break;
	case 1: {
		std::string characterdir = "erkek";
		if(characterno == MenuCanvas::SELECTEDCHARACTER_FEMALE) characterdir = "kadin";
		for(int i = 0; i < 6; i++)  character[i].loadImage("oyun/karakterler/" + characterdir + "/" + characterdir + "_tufek_0" + gToStr(i) + ".png");
		break;
	}
	case 2: {
		enemyframenum[ENEMYANIMATION_WALK] = 8;
		enemyframenum[ENEMYANIMATION_ATTACK] = 16;
		enemyframenum[ENEMYANIMATION_DEATH] = 14;
		for(int i = 0; i < enemyanimationnum; i++) {
			std::string animationdir = "walk/Walk_0";
			if(i == ENEMYANIMATION_ATTACK) animationdir = "attack/attack1_0";
			if(i == ENEMYANIMATION_DEATH) animationdir = "death/Death_0";
			for(int j = 0; j < enemyframenum[i]; j++) {
				std::string imageno = gToStr(j);
				if(j < 10) imageno = "0" + gToStr(j);
				enemy[i][j].loadImage("oyun/dusmanlar/" + animationdir + imageno + ".png");
			}
		}
		break;
	}
	case 3:
		levelmap.loadImage("oyun/haritalar/radar" + gToStr((level % 3) + 1) + ".jpg");
		break;
	case 4:
		levelmapsign1.loadImage("oyun/haritalar/radarisaret1.png");
		break;
	case 5:
		levelmapsign2.loadImage("oyun/haritalar/radarisaret2.png");
		break;
	case 6:
		bulletimage[0].loadImage("oyun/objeler/mermi.png");
		break;
	case 7:
		bulletimage[1].loadImage("oyun/objeler/mermi2.png");
		break;
	case 8: {
		std::string characterdir = "erkek";
		if(characterno == MenuCanvas::SELECTEDCHARACTER_FEMALE) characterdir = "kadin";
		charactericon.loadImage("oyun/gui/" + characterdir + "ikon.png");
		break;
	}
	case 9:
		healthicon.loadImage("oyun/gui/element_0098_Layer-100.png");
		break;
	case 10:
		shieldicon.loadImage("oyun/gui/element_0100_Layer-102.png");
		break;
	case 11:
		progressbarframe.loadImage("oyun/gui/element_0092_Layer-94.png");
		break;
	case 12:
		progressbarbackground.loadImage("oyun/gui/element_0077_Layer-79.png");
		break;
	case 13:
	    healthbar.loadImage("oyun/gui/element_0076_Layer-78.png");
	    break;
	case 14:
		shieldbar.loadImage("oyun/gui/element_0076_Layer-78b.png");
		break;
	case 15:
		pausedialog.loadImage("oyun/gui/dialogue_pause.png");
		break;
	case 16:
		continuebutton.loadImage("oyun/gui/button_continue.png");
		break;
	case 17:
		mainmenubutton.loadImage("oyun/gui/button_mainmenu.png");
		break;
	case 18:
	    gameoverdialog.loadImage("oyun/gui/dialogue_gameover.png");
	    break;
	case 19:
	    replaybutton.loadImage("oyun/gui/button_replay.png");
	    break;
	case 20:
	    youwindialog.loadImage("oyun/gui/dialogue_youwin.png");
	    break;
	case 21:
	    nextlevelbutton.loadImage("oyun/gui/button_nextlevel.png");
	    break;
	case 22:
		fpsfont.loadFont("FreeSans.ttf", 12);
		break;
	case 23:
	    scoretextfont.loadFont("BlackOpsOne-Regular.ttf", 40);
		break;
	case 24:
	    scorefont.loadFont("BlackOpsOne-Regular.ttf", 60);
		break;
	case 25:
		healthbox.loadImage("oyun/objeler/healthbox.png");
		break;
	case 26:
		levelmapsign3.loadImage("oyun/haritalar/radarisaret3.png");
		break;
	case 99:
		loadVariables();
		break;
	}
}

void GameCanvas::loadVariables() {
	cx = (getWidth() / 2) - (character[0].getWidth() / 2);
	cy = (getHeight() / 2) - (character[0].getHeight() / 2);
	crot = 0.0f;
	keystate = 0;
	cdx = 0.0f;
	cdy = 0.0f;
	cspeed = 4.0f;
	camx = 0.0f;
	camy = 0.0f;
	camleftmargin = getWidth() / 4;
	camrightmargin = getWidth() * 3 / 4;
	camtopmargin = getHeight() / 4;
	cambottommargin = getHeight() * 3 / 4;
	enemynum = 3;
	for(int i = 0; i < enemynum; i++) {
		Enemy e;
		enemies.push_back(e);
		float ex, ey;
		do {
			ex = gRandom(background.getWidth() - enemy[ENEMYANIMATION_WALK][0].getWidth());
			ey = gRandom(background.getHeight() - enemy[ENEMYANIMATION_WALK][0].getHeight());
		} while(ex < getWidth() && ey < getHeight());

		enemies[i].setPosition(ex, ey);
		enemies[i].setRotation(0.0f);
		enemies[i].setAnimationNo(ENEMYANIMATION_WALK);
		enemies[i].setFrameNo(gRandom(enemyframenum[ENEMYANIMATION_WALK]));
		enemies[i].setFrameCounterLimit(3);
		enemies[i].setFrameCounter(gRandom(enemies[i].getFrameCounterLimit()));
	}
	levelmapx = getWidth() - levelmap.getWidth() - (levelmap.getWidth() / 2);
	levelmapy = levelmap.getHeight() / 2;
	characterframeno = 0;
	characterframecounter = 0;
	characterframecounterlimit = 10;
	bulletspeed = cspeed * 5;
	muzzleangle = gRadToDeg(std::atan2(0 - (character[0].getHeight() / 2) + 10, 42 - (character[0].getWidth() / 2) - 5)) + 90.0f;
	muzzledistance = std::sqrt(std::pow(0 - (character[0].getHeight() / 2) + 10, 2) + std::pow(42 - (character[0].getWidth() / 2) - 5, 2));
	enemyrighthandangle = gRadToDeg(std::atan2(116 - (enemy[0][0].getHeight() / 2), 58 - (enemy[0][0].getWidth() / 2))) - 90.0f;
	enemyrighthanddistance = std::sqrt(std::pow(116 - (enemy[0][0].getHeight() / 2), 2) + std::pow(58 - (enemy[0][0].getWidth() / 2), 2));
	enemylefthandangle = gRadToDeg(std::atan2(113 - (enemy[0][0].getHeight() / 2), 92 - (enemy[0][0].getWidth() / 2))) - 90.0f;
	enemylefthanddistance = std::sqrt(std::pow(113 - (enemy[0][0].getHeight() / 2), 2) + std::pow(92 - (enemy[0][0].getWidth() / 2), 2));
	deadenemynum = 0;
	cinitialhealth = 100.0f;
	chealth = cinitialhealth;
	charactericonx = charactericon.getWidth() / 2;
	charactericony = charactericon.getHeight() / 2;
	healthiconx = charactericonx + charactericon.getWidth() + healthicon.getWidth() / 2;
	healthicony = charactericony + 5.0f;
	shieldiconx = healthiconx + 3.0f;
	shieldicony = healthicony + healthicon.getHeight() + 5.0f;
	healthbarframex = healthiconx + healthicon.getWidth() + 10.0f;
	healthbarframey = healthicony + 2.0f;
	healthbarbackgroundx = healthbarframex + 5.0f;
	healthbarbackgroundy = healthbarframey + 8.0f;
	shieldbarframex = shieldiconx + shieldicon.getWidth() + 10.0f;
	shieldbarframey = shieldicony + 2.0f;
	shieldbarbackgroundx = shieldbarframex + 5.0f;
	shieldbarbackgroundy = shieldbarframey + 8.0f;
	dialogx = (getWidth() - pausedialog.getWidth()) / 2;
	dialogy = (getHeight() - pausedialog.getHeight()) / 2;
	leftbuttonx = dialogx + (pausedialog.getWidth() / 2) - continuebutton.getWidth() - 15;
	leftbuttony = dialogy + (pausedialog.getHeight() * 3 / 4 - continuebutton.getHeight());
	rightbuttonx = dialogx + (pausedialog.getWidth() / 2) + 15;
	rightbuttony = leftbuttony;
	pausedialogshown = false;
	gameoverdialogshown = false;
	youwindialogshown = false;
	scoretextx = dialogx + (pausedialog.getWidth() - scoretextfont.getStringWidth("SCORE")) / 2;
	scoretexty = dialogy + pausedialog.getHeight() * 2 / 7;
	scorex = 0;
	scorey = dialogy + pausedialog.getHeight() * 8 / 15;
	root->setMusicPause(!root->musicon, gApp::MUSIC_GAME);
	healthboxdylimit = 10;
	healthboxx = gRandom(background.getWidth() - healthbox.getWidth());
	healthboxy = gRandom(background.getHeight() - healthbox.getHeight() - healthboxdylimit);
	ishealthboxtaken = false;
	healthboxinitialy = healthboxy;
	healthboxdy = 1;


	//OPTIMIZATION VARIABLES
	gw = getWidth();
	gh = getHeight();
	bgw = background.getWidth();
	bgh = background.getHeight();
	cgw = character[0].getWidth();
	cgh = character[0].getHeight();
	hbw = healthbox.getWidth();
	hbh = healthbox.getHeight();
	mcagw4 = gw / 4;
	mcagh4 = gh / 4;
	mcagw34 = gw * 3 / 4;
	mcagh34 = gh * 3 / 4;
	meni = 0;
	cgw2 = cgw / 2;
	cgh2 = cgh / 2;
	engw = enemy[0][0].getWidth();
	engh = enemy[0][0].getHeight();
	engw2 = engw / 2;
	engh2 = engh / 2;
	pdgw = pausedialog.getWidth();
	pdgh = pausedialog.getHeight();
	bugw0 = bulletimage[0].getWidth();
	bugh0 = bulletimage[0].getHeight();
	bugw1 = bulletimage[1].getWidth();
	bugh1 = bulletimage[1].getHeight();
	dguihbgw = healthbar.getWidth();
	dguihbgh = healthbar.getHeight();
	dguisbgw = shieldbar.getWidth();
	dguisbgh = shieldbar.getHeight();
	mbui = 0;
	mbuj = 0;
	deni = 0;
	dbui = 0;
	dlmi = 0;
}

void GameCanvas::drawLoadingScreen() {
	loadingbackground.draw(0, 0, getWidth(), getHeight());
	loadingtext.draw(loadingtextx, loadingtexty);
	loadingbar.drawSub(loadingbarx, loadingbary, loadingbar.getWidth(), loadingbar.getHeight() / 2, 0, 0, loadingbar.getWidth(), loadingbar.getHeight() / 2);
	loadingbar.drawSub(loadingbarx, loadingbary, loadcounter * loadingbar.getWidth() / (loadcounterlimit - 1), loadingbar.getHeight() / 2, 0, loadingbar.getHeight() / 2, loadingbar.getWidth() - loadcounter * loadingbar.getWidth() / (loadcounterlimit - 1), loadingbar.getHeight() / 2);
}
