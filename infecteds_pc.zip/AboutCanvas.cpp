#include "AboutCanvas.h"
#include "MenuCanvas.h"

AboutCanvas::AboutCanvas(gApp *root) : gBaseCanvas(root) {
	this->root = root;
}

AboutCanvas::~AboutCanvas() {

}

void AboutCanvas::setup() {
	background.loadImage("menu/arkaplan.jpg");
	textfont.loadFont("FreeSans.ttf", 20);
	text[0] = "GELISTIRENLER";
	text[1] = "Fatma Ceyda Gokce";
	text[2] = "Batuhan Aydin";
	text[3] = "Halit Muhammed";
	text[4] = "Batuhan Yilmaz";
	text[5] = "Cevher Kemal Sirin";
	text[6] = "Furkan Emir Bulut";
	text[7] = "Yavuz Selim Erdonmez";
	text[8] = "Omer Tarik Erik";
	text[9] = "Furkan Komurlu";
	text[10] = "Eren Buke";
	text[11] = "Murat Ergin";
	text[12] = "";
	text[13] = "Bu oyun Gamelab Istanbul tarafindan duzenlenen";
	text[14] = "C++ ile Oyun Programlama Egitiminde gelistirilmistir. (c)2022";
	for(int i = 0; i < linenum; i++) textx[i] = (getWidth() - textfont.getStringWidth(text[i])) / 2;
	lineh = textfont.getSize() * 3 / 2;
	firstliney = (getHeight() - (linenum * lineh)) / 2;
}

void AboutCanvas::update() {
	firstliney--;
	if(firstliney < (-lineh * linenum)) firstliney = getHeight() + lineh;
}

void AboutCanvas::draw() {
	background.draw(0, 0, getWidth(), getHeight());
	for(int i = 0; i < linenum; i++) {
		setColor(0, 0, 0);
		textfont.drawText(text[i], textx[i] + 2, firstliney + (i * lineh) + 2);
		setColor(214, 255, 175);
		textfont.drawText(text[i], textx[i], firstliney + (i * lineh));
		setColor(255, 255, 255);
	}
}

void AboutCanvas::keyPressed(int key) {

}
void AboutCanvas::keyReleased(int key) {

}

void AboutCanvas::mouseMoved(int x, int y ) {

}

void AboutCanvas::mouseDragged(int x, int y, int button) {

}

void AboutCanvas::mousePressed(int x, int y, int button) {

}

void AboutCanvas::mouseReleased(int x, int y, int button) {
	MenuCanvas* newcanvas = new MenuCanvas(root);
	root->setCurrentCanvas(newcanvas);
}

void AboutCanvas::mouseEntered() {

}

void AboutCanvas::mouseExited() {

}

void AboutCanvas::showNotify() {

}

void AboutCanvas::hideNotify() {

}
