#ifndef SRC_MENUCANVAS_H_
#define SRC_MENUCANVAS_H_

#include "gBaseCanvas.h"
#include "gApp.h"
#include "gImage.h"
#include "gFont.h"
#include "GameCanvas.h"
#include "AboutCanvas.h"
#include "gFmodSound.h"

class MenuCanvas: public gBaseCanvas {
public:
	static const int SELECTEDCHARACTER_MALE = 0, SELECTEDCHARACTER_FEMALE = 1;

	MenuCanvas(gApp* root);
	virtual ~MenuCanvas();

	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered();
	void mouseExited();

	void showNotify();
	void hideNotify();

private:
	gApp* root;
	gImage background;
	gImage mainmenu;
	gImage tick;
	gImage ban;
	gFont versionfont;

	float mainmenux, mainmenuy;
	int playbuttonleft, playbuttonright, playbuttontop, playbuttonbottom;
	int selectedcharacterno;
	float charactermaleleft, charactermaleright, charactermaletop, charactermalebottom;
	float characterfemaleleft, characterfemaleright, characterfemaletop, characterfemalebottom;
	float musicbuttonleft, musicbuttonright, musicbuttontop, musicbuttonbottom;
	float soundbuttonleft, soundbuttonright, soundbuttontop, soundbuttonbottom;
	float versionfontx, versionfonty, versionfontw, direction;
	float infobuttonleft, infobuttonright, infobuttontop, infobuttonbottom; //97 193, 191 216
};

#endif /* SRC_MENUCANVAS_H_ */
