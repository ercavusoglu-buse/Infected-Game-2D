#ifndef SRC_ENEMY_H_
#define SRC_ENEMY_H_

class Enemy {
public:
	Enemy();
	virtual ~Enemy();

	void setPosition(float X, float Y);
	void setRotation(float rotation);
	void setAnimationNo(int animationNo);
	void setFrameNo(int frameNo);
	void setFrameCounter(int frameCounter);
	void setFrameCounterLimit(int frameCounterLimit);

	float getX();
	float getY();
	float getRotation();

	int getAnimationNo();
	int getFrameNo();
	int getFrameCounter();
	int getFrameCounterLimit();

private:
	float x, y, rotation;
	int animationno, frameno;
	int framecounter, framecounterlimit;
};

#endif /* SRC_ENEMY_H_ */
