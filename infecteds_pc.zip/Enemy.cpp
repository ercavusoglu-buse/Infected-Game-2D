#include "Enemy.h"

Enemy::Enemy() {
	x = 0.0f;
	y = 0.0f;
	rotation = 0.0f;
	animationno = 0;
	frameno = 0;
	framecounter = 0;
	framecounterlimit = 0;
}

Enemy::~Enemy() {
}

void Enemy::setPosition(float X, float Y) {
	x = X;
	y = Y;
}

void Enemy::setRotation(float rotation) {
	this->rotation = rotation;
}

void Enemy::setAnimationNo(int animationNo) {
	this->animationno = animationNo;
}

void Enemy::setFrameNo(int frameNo) {
	frameno = frameNo;
}

void Enemy::setFrameCounter(int frameCounter) {
	framecounter = frameCounter;
}

void Enemy::setFrameCounterLimit(int frameCounterLimit) {
	framecounterlimit = frameCounterLimit;
}

float Enemy::getX() {
	return x;
}

float Enemy::getY() {
	return y;
}

float Enemy::getRotation() {
	return rotation;
}

int Enemy::getAnimationNo() {
	return animationno;
}

int Enemy::getFrameNo() {
	return frameno;
}

int Enemy::getFrameCounter() {
	return framecounter;
}

int Enemy::getFrameCounterLimit() {
	return framecounterlimit;
}
