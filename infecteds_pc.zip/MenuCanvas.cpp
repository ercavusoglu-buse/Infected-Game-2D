#include "MenuCanvas.h"

MenuCanvas::MenuCanvas(gApp* root) : gBaseCanvas(root) {
	this->root = root;
}

MenuCanvas::~MenuCanvas() {
}

void MenuCanvas::setup() {
	background.loadImage("menu/arkaplan.jpg");
	mainmenu.loadImage("menu/anamenu.png");
	tick.loadImage("menu/tikler.png");
	ban.loadImage("menu/ban.png");
	versionfont.loadFont("BlackOpsOne-Regular.ttf", 30);
	mainmenux = (getWidth() - mainmenu.getWidth()) / 2;
	mainmenuy = (getHeight() - mainmenu.getHeight()) / 2;
	playbuttonleft = mainmenux + 76;
	playbuttonright = mainmenux + 214;
	playbuttontop = mainmenuy + 297;
	playbuttonbottom = mainmenuy + 353;
	charactermaleleft = mainmenux + 209;
	charactermaleright = mainmenux + 383;
	charactermaletop = mainmenuy + 65;
	charactermalebottom = mainmenuy + 403;
	characterfemaleleft = mainmenux + 389;
	characterfemaleright = mainmenux + 558;
	characterfemaletop = mainmenuy + 65;
	characterfemalebottom = mainmenuy + 403;
	musicbuttonleft = mainmenux + 97;
	musicbuttonright = mainmenux + 192;
	musicbuttontop = mainmenuy + 141;
	musicbuttonbottom = mainmenuy + 164;
	soundbuttonleft = mainmenux + 97;
	soundbuttonright = mainmenux + 192;
	soundbuttontop = mainmenuy + 167;
	soundbuttonbottom = mainmenuy + 190;
	versionfontx = 0;
	versionfonty = getHeight() - versionfont.getSize() / 2;
	versionfontw = versionfont.getStringWidth("INFECTEDS v1.0");
	direction = 1;
	infobuttonleft = mainmenux + 97;
	infobuttonright = mainmenux + 191;
	infobuttontop = mainmenuy + 193;
	infobuttonbottom = mainmenuy + 216;
	root->setMusicPause(!root->musicon, gApp::MUSIC_MENU);

	root->getDatabase()->execute("SELECT characterno FROM SETTINGS");
	std::string settingsdata = "";
	while(root->getDatabase()->hasSelectData()) {
		settingsdata = root->getDatabase()->getSelectData();
	}
	std::vector<std::string> data = gSplitString(settingsdata, "|");
	selectedcharacterno = gToInt(data[1]);
}

void MenuCanvas::update() {
	versionfontx += direction;
	if(versionfontx + versionfontw >= getWidth() || versionfontx <= 0) direction = -direction;
}

void MenuCanvas::draw() {
	background.draw(0, 0, getWidth(), getHeight());
	mainmenu.draw(mainmenux, mainmenuy);
	tick.drawSub(charactermaleright - (tick.getWidth() * 3 / 4), charactermalebottom - (tick.getHeight() * 3 / 2), (tick.getWidth() / 2) * std::fabs(1 - selectedcharacterno - SELECTEDCHARACTER_MALE), 0, tick.getWidth() / 2, tick.getHeight());
	tick.drawSub(characterfemaleleft + (tick.getWidth() / 4), characterfemalebottom - (tick.getHeight() * 3 / 2), (tick.getWidth() / 2) * std::fabs(1 - selectedcharacterno - SELECTEDCHARACTER_FEMALE), 0 , tick.getWidth() / 2, tick.getHeight());
	if(!root->musicon) {
		ban.draw((musicbuttonleft + musicbuttonright) / 2 - ban.getWidth() / 2, (musicbuttontop + musicbuttonbottom) / 2 - ban.getHeight() / 2);
	}
	if(!root->soundon) {
		ban.draw((soundbuttonleft + soundbuttonright) / 2 - ban.getWidth() / 2, (soundbuttontop + soundbuttonbottom) / 2 - ban.getHeight() / 2);
	}
	setColor(0, 0, 0);
	versionfont.drawText("INFECTEDS v1.0", versionfontx + (versionfont.getStringWidth("INFECTEDS v1.0") / 100), versionfonty + (versionfont.getSize() / 4));
	setColor(185, 204, 104);
	versionfont.drawText("INFECTEDS v1.0", versionfontx, versionfonty + 5);
	setColor(255, 255, 255);
}

void MenuCanvas::keyPressed(int key) {

}

void MenuCanvas::keyReleased(int key) {

}

void MenuCanvas::mouseMoved(int x, int y ) {

}

void MenuCanvas::mouseDragged(int x, int y, int button) {

}

void MenuCanvas::mousePressed(int x, int y, int button) {

}

void MenuCanvas::mouseReleased(int x, int y, int button) {
	if(x >= playbuttonleft && x <= playbuttonright && y >= playbuttontop && y <= playbuttonbottom) {
		root->playSound(gApp::SOUNDEFFECT_NEXT);
		root->setMusicPause(true, gApp::MUSIC_MENU);
		GameCanvas* newcanvas = new GameCanvas(root);
		newcanvas->setCharacterNo(selectedcharacterno);
		root->setCurrentCanvas(newcanvas);
	}

	if(x >= infobuttonleft && x <= infobuttonright && y >= infobuttontop && y <= infobuttonbottom) {
		root->playSound(gApp::SOUNDEFFECT_CLICK);
		AboutCanvas* newcanvas = new AboutCanvas(root);
		root->setCurrentCanvas(newcanvas);
	}

	if(x >= charactermaleleft && x <= charactermaleright && y >= charactermaletop && y <= charactermalebottom) {
		root->playSound(gApp::SOUNDEFFECT_CLICK);
		selectedcharacterno = SELECTEDCHARACTER_MALE;
		root->getDatabase()->execute("UPDATE SETTINGS SET characterno=" + gToStr(selectedcharacterno));
	}

	if(x >= characterfemaleleft && x <= characterfemaleright && y >= characterfemaletop && y <= characterfemalebottom) {
		root->playSound(gApp::SOUNDEFFECT_CLICK);
		selectedcharacterno = SELECTEDCHARACTER_FEMALE;
		root->getDatabase()->execute("UPDATE SETTINGS SET characterno=" + gToStr(selectedcharacterno));
	}

	if(x >= musicbuttonleft && x <= musicbuttonright && y >= musicbuttontop && y <= musicbuttonbottom) {
		root->playSound(gApp::SOUNDEFFECT_CLICK);
		root->musicon = !root->musicon;
		root->saveSettings();
		root->setMusicPause(!root->musicon, gApp::MUSIC_MENU);
	}

	if(x >= soundbuttonleft && x <= soundbuttonright && y >= soundbuttontop && y <= soundbuttonbottom) {
		root->playSound(gApp::SOUNDEFFECT_CLICK);
		root->soundon = !root->soundon;
		root->saveSettings();
	}
}

void MenuCanvas::mouseEntered() {

}

void MenuCanvas::mouseExited() {

}

void MenuCanvas::showNotify() {

}

void MenuCanvas::hideNotify() {

}
