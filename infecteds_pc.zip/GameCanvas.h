#ifndef GAMECANVAS_H_
#define GAMECANVAS_H_

#include "gBaseCanvas.h"
#include "gApp.h"
#include "gImage.h"
#include "Enemy.h"
#include "MenuCanvas.h"
#include "gFont.h"


class GameCanvas : public gBaseCanvas {
public:
	GameCanvas(gApp* root);
	virtual ~GameCanvas();

	void setup();
	void update();
	void draw();

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered();
	void mouseExited();

	void showNotify();
	void hideNotify();

	void setLevelNo(int levelNo);
	void setCharacterNo(int characterNo);
	void setScore(int score);

private:
	static const int KEY_NONE = 0, KEY_W = 1, KEY_S = 2, KEY_A = 4, KEY_D = 8;  //Anumaration
	static const int ENEMYANIMATION_WALK, ENEMYANIMATION_ATTACK, ENEMYANIMATION_DEATH;
	static const int BULLETSENDER_CHARACTER, BULLETSENDER_ENEMY;
	enum {
		GAMESTATE_LOADING,
		GAMESTATE_PLAYING
	};

	static const int characterframenum = 6;
	static const int enemyanimationnum = 3, enemymaxframenum = 16;

	gApp* root;
	gImage logo;
	gImage background;
	gImage character[characterframenum];
	gImage enemy[enemyanimationnum][enemymaxframenum];
	gImage levelmap;
	gImage levelmapsign1;
	gImage levelmapsign2;
	gImage bulletimage[2];
	gImage charactericon;
	gImage healthicon;
	gImage shieldicon;
	gImage progressbarframe;
	gImage progressbarbackground;
	gImage healthbar;
	gImage shieldbar;
	gImage pausedialog;
	gImage continuebutton;
	gImage mainmenubutton;
	gImage gameoverdialog;
	gImage replaybutton;
	gImage youwindialog;
	gImage nextlevelbutton;
	gImage loadingbackground;
	gImage loadingtext;
	gImage loadingbar;
	gImage healthbox;
	gImage levelmapsign3;
	gFont fpsfont;
	gFont scoretextfont;
	gFont scorefont;
	float cy,cx;
	float crot;
	int keystate;
	void moveCharacter();
	void moveCamera();
	void moveEnemies();
	void moveBullets();
	void drawBackground();
	void drawCharacter();
	void drawEnemies();
	void drawLevelMap();
	void drawBullets();
	void drawGUI();
	bool checkCollision(int xLeft1, int yUp1, int xRight1, int yBottom1, int xLeft2, int yUp2, int xRight2, int yBottom2);
	void generateBullet(float bulletx, float bullety, float bulletdx, float bulletdy, float rotation, int bulletSender);
	void loadInitialAssets();
	void loadAssets();
	void loadAsset(int assetNo);
	void loadVariables();
	void drawLoadingScreen();
	void moveObjects();
	void drawObjects();
	float cdx, cdy;
	float cspeed;
	float camx, camy;
	int camleftmargin, camrightmargin, camtopmargin, cambottommargin;

	std::vector<Enemy> enemies;
	int enemynum;
	float levelmapx, levelmapy;
	int characterframeno;
	int characterframecounter, characterframecounterlimit;
	int enemyframenum[enemyanimationnum];
	std::vector<std::vector<float>> bullets;
	float bulletspeed;
	float muzzleangle, muzzledistance;
	float enemyrighthandangle, enemyrighthanddistance;
	float enemylefthandangle, enemylefthanddistance;
	int deadenemynum;
	float chealth, cinitialhealth;
	float charactericonx, charactericony;
	float healthiconx, healthicony;
	float shieldiconx, shieldicony;
	float healthbarframex, healthbarframey;
	float healthbarbackgroundx, healthbarbackgroundy;
	float shieldbarframex, shieldbarframey;
	float shieldbarbackgroundx, shieldbarbackgroundy;
	float dialogx, dialogy;
	float leftbuttonx, leftbuttony;
	float rightbuttonx, rightbuttony;
	bool pausedialogshown;
	bool gameoverdialogshown;
	bool youwindialogshown;
	int level;
	int characterno;
	int score;
	float scoretextx, scoretexty;
	float scorex, scorey;
	int loadingbarx, loadingbary;
	int loadingtextx, loadingtexty;
	int loadcounter, loadcounterlimit;
	int gamestate;
	int healthboxx, healthboxy;
	int healthboxdylimit;
	bool ishealthboxtaken;
	int healthboxinitialy, healthboxdy;


	//OPTIMIZATION VARIABLES
	int gw, gh;
	int cgw, cgh;
	int bgw, bgh;
	int hbw, hbh;
	int mcagw4, mcagh4, mcagw34, mcagh34;
	int meni;
	int cgw2, cgh2;
	int engw, engh;
	int engw2, engh2;
	int pdgw, pdgh;
	int bugw0, bugh0;
	int bugw1, bugh1;
	int dguihbgw, dguihbgh;
	int dguisbgw, dguisbgh;
	int mbui;
	int mbuj;
	int deni;
	int dbui;
	int dlmi;
};

#endif /* GAMECANVAS_H_ */
