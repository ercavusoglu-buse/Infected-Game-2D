#include "gApp.h"
#include "GameCanvas.h"
#include "MenuCanvas.h"

gApp::gApp() {
}

gApp::~gApp() {
}

void gApp::setup() {
	soundeffect[SOUNDEFFECT_NEXT].loadSound("sound_next5.wav");
	soundeffect[SOUNDEFFECT_CLICK].loadSound("sound_click2.wav");
	soundeffect[SOUNDEFFECT_GUNSHOT].loadSound("gun_shot_2.wav");
	soundeffect[SOUNDEFFECT_ENEMYDEATH].loadSound("monster_death.wav");
	soundeffect[SOUNDEFFECT_ENEMYFOOTSTEP].loadSound("monster_footsteps.wav");
	music[MUSIC_MENU].loadSound("birthofahero.mp3");
	music[MUSIC_GAME].loadSound("savage-law.mp3");

	settings.openDatabase("settings.db");
	settings.execute("SELECT * FROM SETTINGS");
	std::string settingsdata = "";
	while(settings.hasSelectData()) {
		settingsdata = settings.getSelectData();
	}
	std::vector<std::string> data = gSplitString(settingsdata, "|");

	musicon = gToInt(data[1]);
	soundon = gToInt(data[2]);

	music[MUSIC_MENU].play();
	music[MUSIC_MENU].setPaused(!musicon);
	music[MUSIC_GAME].play();
	music[MUSIC_GAME].setPaused(true);
	music[MUSIC_MENU].setLoopType(gBaseSound::LOOPTYPE_NORMAL);
	music[MUSIC_GAME].setLoopType(gBaseSound::LOOPTYPE_NORMAL);

	MenuCanvas *cnv = new MenuCanvas(this);
	appmanager->setCurrentCanvas(cnv);
}

void gApp::update() {
}

void gApp::playSound(int soundNo) {
	if(soundon) soundeffect[soundNo].play();
}

void gApp::setSoundPause(bool isPaused, int soundNo) {
	soundeffect[soundNo].setPaused(isPaused);
}

bool gApp::isSoundPlaying(int soundNo) {
	return soundeffect[soundNo].isPlaying();
}

void gApp::playMusic(int musicNo) {
	music[musicNo].play();
}

void gApp::stopMusic(int musicNo) {
	music[musicNo].stop();
}

void gApp::setMusicPause(bool isPaused, int musicNo) {
	music[musicNo].setPaused(isPaused);
}

bool gApp::isMusicPlaying(int musicNo) {
	return music[musicNo].isPlaying();
}

void gApp::saveSettings() {
	settings.execute("UPDATE SETTINGS SET musicon=" + gToStr(musicon) + ", soundon=" + gToStr(soundon));
}

gDatabase* gApp::getDatabase() {
	return &settings;
}
